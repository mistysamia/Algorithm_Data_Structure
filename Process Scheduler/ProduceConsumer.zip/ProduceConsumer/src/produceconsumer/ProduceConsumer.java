/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package produceconsumer;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedList;
import java.util.Scanner;
import static produceconsumer.ProduceConsumer.n;

/**
 *
 * @author HP
 */
class Pair {

    public int key, val;

    public Pair(int key, int val) {
        this.key = key;
        this.val = val;
    }
}

class ProducerConsumer implements Runnable {
    Deque<Integer> deque = new LinkedList<>();
    int capacity = ProduceConsumer.n;
    public void produce() throws InterruptedException {
        int iteration = 0;
        while (true) {
            synchronized (this) {
                while (deque.size() == capacity) {

                    wait();
                    //break;
                }
                iteration++;
                deque.add(iteration % capacity);
                int index = iteration % capacity;
                System.out.println("Producer " + ProduceConsumer.array[index].val
                        + ": Data " + ProduceConsumer.array[index].key + " is inserted in the buffer");
                System.out.println("Empty space: " + (capacity - deque.size()));
                System.out.println("Full space: " + deque.size());

                notifyAll();
                Thread.sleep(1000);

            }
        }
    }

    public void consume() throws InterruptedException {
        while (true) {
            synchronized (this) {
                while (deque.size() == 0) {
                    wait();

                }

                int index = deque.removeFirst();
                System.out.println("Consumed " + ProduceConsumer.array[index].val
                        + ": Consumed Data " + ProduceConsumer.array[index].key +
                        " from the buffer ");
                System.out.println("Full space: " + deque.size());

                notifyAll();
                Thread.sleep(1000);
            }
        }
    }

    @Override
    public void run() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

public class ProduceConsumer {

    public static int n;
    public static Pair[] array = new Pair[100];

    public static void main(String[] args) throws InterruptedException {

        Scanner sc = new Scanner(System.in);
        System.out.print("Buffer Size: ");

        n = sc.nextInt();

        System.out.println("Enter all the data: ");
        for (int i = 0; i < n; i++) {
            int data = sc.nextInt();
            array[i] = new Pair(data, i + 1);
        }
        
        ProducerConsumer produceConsume = new ProducerConsumer();
        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    produceConsume.produce();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    produceConsume.consume();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        t1.start();
        t2.start();
    }
}
